﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Random los = new Random();

            

            try
            {
                
                textBox1.AppendText(los.Next(1, 10).ToString() );
                textBox2.AppendText(los.Next(1, 10).ToString());
                textBox3.AppendText(los.Next(1, 10).ToString());
                textBox4.AppendText(los.Next(1, 10).ToString());
                textBox5.AppendText(los.Next(1, 10).ToString());
                textBox6.AppendText(los.Next(1, 10).ToString());
                textBox7.AppendText(los.Next(1, 10).ToString());
                textBox8.AppendText(los.Next(1, 10).ToString());

                

            }
            catch
            {
                MessageBox.Show("Błąd danych");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            label9.Text = "";
            label10.Text = "";
            label11.Text = "";
            label12.Text = "";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int ile = 0;
                int a, b, c, d, f, g, h, k, w, x, y, z, aa, bb, cc, dd;

                a = Convert.ToInt32(textBox1.Text);
                b = Convert.ToInt32(textBox2.Text);
                c = Convert.ToInt32(textBox3.Text);
                d = Convert.ToInt32(textBox4.Text);
                f = Convert.ToInt32(textBox5.Text);
                g = Convert.ToInt32(textBox6.Text);
                h = Convert.ToInt32(textBox7.Text);
                k = Convert.ToInt32(textBox8.Text);

                w = a * b;
                x = c * d;
                y = f * g;
                z = h * k;

                aa= Convert.ToInt32(textBox9.Text);
                bb= Convert.ToInt32(textBox10.Text);
                cc= Convert.ToInt32(textBox11.Text);
                dd= Convert.ToInt32(textBox12.Text);
                if (aa == w)
                {
                    ile++;
                    label9.Text = "Dobrze!";
                    label9.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    label9.Text = "Źle!";
                    label9.ForeColor = System.Drawing.Color.Red;
                }
                if (bb == x)
                {
                    ile++;
                    label10.Text = "Dobrze!";
                    label10.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    label10.Text = "Źle!";
                    label10.ForeColor = System.Drawing.Color.Red;
                }
                if (cc == y)
                {
                    ile++;
                    label11.Text = "Dobrze!";
                    label11.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    label11.Text = "Źle!";
                    label11.ForeColor = System.Drawing.Color.Red;
                }
                if (dd == z)
                {
                    ile++;
                    label12.Text = "Dobrze!";
                    label12.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    label12.Text = "Źle!";
                    label12.ForeColor = System.Drawing.Color.Red;
                }

                MessageBox.Show("Twój wynik to " + ile + "/4");
            }
            catch
            {
                MessageBox.Show("Błąd danych");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://users.tryton.vlo.gda.pl/s31/DrugaBG-host/");
        }
    }
}
